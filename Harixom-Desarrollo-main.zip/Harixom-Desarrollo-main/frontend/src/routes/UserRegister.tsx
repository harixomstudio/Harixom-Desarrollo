import { createFileRoute } from "@tanstack/react-router";
import UserRegister from "../components/pages/UserRegisterPage";

export const Route = createFileRoute("/UserRegister")({
  component: UserRegisterRoute,
});

function UserRegisterRoute() {
  return <UserRegister title="User Register" />;
}
